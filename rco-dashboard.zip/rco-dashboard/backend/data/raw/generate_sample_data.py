"""
generate_sample_data.py

⚠️ THIS PRODUCES SYNTHETIC / PLACEHOLDER DATA ONLY. ⚠️

It does NOT contain real Sierra Leone statistics. It exists so the
full-stack system can be demonstrated end-to-end without live internet
access to the real sources.

Before using this project for a real application/portfolio piece, replace
this file's output with actual downloaded data from:
  - World Bank Open Data:        https://data.worldbank.org/country/sierra-leone
  - UNICEF Data Warehouse:       https://data.unicef.org/country/sle/
  - DHS Program (SL surveys):    https://dhsprogram.com/data/dataset_admin/index.cfm
  - HDX (humanitarian data):     https://data.humdata.org/group/sle

The real ingestion script (ingest.py) expects a CSV in this same shape:
    district,year,area_type,indicator,value
so once you have real data, reshape it into this format and re-run ingest.py.
"""

import csv
import random

random.seed(42)  # deterministic — not statistically meaningful, just reproducible

DISTRICTS = [
    "Western Area Urban", "Western Area Rural", "Bo", "Bombali", "Bonthe",
    "Kailahun", "Kambia", "Kenema", "Koinadugu", "Kono", "Moyamba",
    "Port Loko", "Pujehun", "Tonkolili", "Falaba", "Karene",
]

YEARS = list(range(2016, 2024))
AREA_TYPES = ["urban", "rural"]

INDICATORS = {
    # indicator_key: (label, plausible_min, plausible_max, unit)
    "primary_enrollment_rate": ("Primary School Net Enrollment Rate", 55, 96, "%"),
    "gender_parity_index_primary": ("Gender Parity Index, Primary Enrollment", 0.85, 1.05, "ratio"),
    "youth_literacy_rate_15_24": ("Youth Literacy Rate (15-24)", 40, 92, "%"),
}

rows = []
for district in DISTRICTS:
    # give each district a base "profile" so trends look plausible, not random noise
    base_enroll = random.uniform(60, 90)
    base_gpi = random.uniform(0.88, 1.02)
    base_lit = random.uniform(45, 85)
    urban_bonus = random.uniform(5, 15)  # urban areas trend higher in this synthetic model

    for area in AREA_TYPES:
        bonus = urban_bonus if area == "urban" else 0
        for i, year in enumerate(YEARS):
            drift = i * random.uniform(0.3, 1.2)  # slow upward drift over years
            noise = random.uniform(-2, 2)

            enroll = max(30, min(99, base_enroll + bonus + drift + noise))
            gpi = max(0.7, min(1.1, base_gpi + (0.01 * i) + random.uniform(-0.02, 0.02)))
            lit = max(20, min(98, base_lit + bonus + drift * 1.1 + noise))

            rows.append([district, year, area, "primary_enrollment_rate", round(enroll, 1)])
            rows.append([district, year, area, "gender_parity_index_primary", round(gpi, 3)])
            rows.append([district, year, area, "youth_literacy_rate_15_24", round(lit, 1)])

with open("sample_education_data.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["district", "year", "area_type", "indicator", "value"])
    writer.writerows(rows)

# Also write an indicator metadata file used by the API layer
with open("indicator_metadata.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["indicator", "label", "unit", "note"])
    for key, (label, lo, hi, unit) in INDICATORS.items():
        writer.writerow([key, label, unit, "SYNTHETIC SAMPLE DATA — not a real statistic"])

print(f"Wrote {len(rows)} synthetic rows to sample_education_data.csv")
