"""
ingest.py — loads raw indicator CSVs into the SQLite database.

Run standalone:
    python -m app.ingest

Designed to be resilient to messy real-world data:
  - skips rows with missing/malformed values (logs them, doesn't crash)
  - coerces types defensively
  - de-duplicates on (district, year, area_type, indicator)
  - reports a summary of what was accepted vs. rejected
"""

import csv
import sqlite3
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
RAW_DIR = BASE_DIR / "data" / "raw"
DB_PATH = BASE_DIR / "data" / "db" / "dashboard.db"

DATA_CSV = RAW_DIR / "sample_education_data.csv"
METADATA_CSV = RAW_DIR / "indicator_metadata.csv"

SCHEMA = """
CREATE TABLE IF NOT EXISTS indicator_metadata (
    indicator TEXT PRIMARY KEY,
    label TEXT NOT NULL,
    unit TEXT,
    note TEXT
);

CREATE TABLE IF NOT EXISTS observations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    district TEXT NOT NULL,
    year INTEGER NOT NULL,
    area_type TEXT NOT NULL,
    indicator TEXT NOT NULL,
    value REAL NOT NULL,
    UNIQUE(district, year, area_type, indicator)
);

CREATE INDEX IF NOT EXISTS idx_obs_indicator ON observations(indicator);
CREATE INDEX IF NOT EXISTS idx_obs_district ON observations(district);
"""

VALID_AREA_TYPES = {"urban", "rural"}


def validate_row(row: dict, line_no: int, errors: list) -> dict | None:
    """Return a cleaned row dict, or None (and log an error) if invalid."""
    district = (row.get("district") or "").strip()
    area_type = (row.get("area_type") or "").strip().lower()
    indicator = (row.get("indicator") or "").strip()

    if not district:
        errors.append(f"line {line_no}: missing district")
        return None
    if area_type not in VALID_AREA_TYPES:
        errors.append(f"line {line_no}: invalid area_type '{area_type}'")
        return None
    if not indicator:
        errors.append(f"line {line_no}: missing indicator")
        return None

    try:
        year = int(row.get("year", ""))
        if not (1990 <= year <= 2100):
            errors.append(f"line {line_no}: year out of plausible range: {year}")
            return None
    except (ValueError, TypeError):
        errors.append(f"line {line_no}: unparseable year '{row.get('year')}'")
        return None

    try:
        value = float(row.get("value", ""))
    except (ValueError, TypeError):
        errors.append(f"line {line_no}: unparseable value '{row.get('value')}' — skipped, NOT guessed")
        return None

    return {
        "district": district,
        "year": year,
        "area_type": area_type,
        "indicator": indicator,
        "value": value,
    }


def load_metadata(conn: sqlite3.Connection) -> int:
    if not METADATA_CSV.exists():
        print(f"WARNING: {METADATA_CSV} not found — skipping metadata load", file=sys.stderr)
        return 0
    count = 0
    with open(METADATA_CSV, newline="") as f:
        for row in csv.DictReader(f):
            conn.execute(
                "INSERT OR REPLACE INTO indicator_metadata (indicator, label, unit, note) "
                "VALUES (?, ?, ?, ?)",
                (row["indicator"], row["label"], row.get("unit"), row.get("note")),
            )
            count += 1
    return count


def load_observations(conn: sqlite3.Connection) -> tuple[int, int, list]:
    if not DATA_CSV.exists():
        raise FileNotFoundError(
            f"{DATA_CSV} not found. Run generate_sample_data.py first, "
            f"or place your real CSV at this path."
        )

    accepted, rejected = 0, 0
    errors: list[str] = []

    with open(DATA_CSV, newline="") as f:
        reader = csv.DictReader(f)
        for line_no, row in enumerate(reader, start=2):  # header is line 1
            clean = validate_row(row, line_no, errors)
            if clean is None:
                rejected += 1
                continue
            try:
                conn.execute(
                    "INSERT OR REPLACE INTO observations "
                    "(district, year, area_type, indicator, value) VALUES (?, ?, ?, ?, ?)",
                    (clean["district"], clean["year"], clean["area_type"],
                     clean["indicator"], clean["value"]),
                )
                accepted += 1
            except sqlite3.Error as e:
                errors.append(f"line {line_no}: DB error — {e}")
                rejected += 1

    return accepted, rejected, errors


def main():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.executescript(SCHEMA)

    meta_count = load_metadata(conn)
    accepted, rejected, errors = load_observations(conn)
    conn.commit()

    print(f"Metadata rows loaded: {meta_count}")
    print(f"Observations accepted: {accepted}")
    print(f"Observations rejected: {rejected}")
    if errors:
        print("\nFirst 10 rejection reasons:")
        for e in errors[:10]:
            print(f"  - {e}")

    conn.close()


if __name__ == "__main__":
    main()
