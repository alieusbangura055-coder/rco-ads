"""
main.py — FastAPI backend for the Sierra Leone education indicators dashboard.

Run:
    uvicorn app.main:app --reload --port 8000

Interactive API docs available at:
    http://localhost:8000/docs
"""

import sqlite3
from pathlib import Path

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "data" / "db" / "dashboard.db"

app = FastAPI(
    title="Sierra Leone Education Indicators API",
    description=(
        "Serves cleaned education-access indicators for Sierra Leone districts. "
        "NOTE: sample deployment uses synthetic placeholder data — see README."
    ),
    version="0.1.0",
)

# Allow the local Vite dev server to call this API during development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_methods=["GET"],
    allow_headers=["*"],
)


def get_conn():
    if not DB_PATH.exists():
        raise HTTPException(
            status_code=500,
            detail="Database not found. Run `python -m app.ingest` first.",
        )
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.get("/api/indicators")
def list_indicators():
    """List available indicators with metadata."""
    conn = get_conn()
    rows = conn.execute("SELECT indicator, label, unit, note FROM indicator_metadata").fetchall()
    conn.close()
    if not rows:
        raise HTTPException(status_code=404, detail="No indicator metadata loaded.")
    return [dict(r) for r in rows]


@app.get("/api/districts")
def list_districts():
    """List all districts present in the data."""
    conn = get_conn()
    rows = conn.execute("SELECT DISTINCT district FROM observations ORDER BY district").fetchall()
    conn.close()
    return [r["district"] for r in rows]


@app.get("/api/data")
def get_data(
    indicator: str = Query(..., description="Indicator key, e.g. primary_enrollment_rate"),
    district: str | None = Query(None, description="Optional: filter to one district"),
    area_type: str | None = Query(None, description="Optional: 'urban' or 'rural'"),
):
    """
    Return observations for one indicator, optionally filtered by district
    and/or area_type. This is the main data endpoint the frontend charts use.
    """
    conn = get_conn()

    meta = conn.execute(
        "SELECT indicator, label, unit, note FROM indicator_metadata WHERE indicator = ?",
        (indicator,),
    ).fetchone()
    if meta is None:
        conn.close()
        raise HTTPException(status_code=404, detail=f"Unknown indicator '{indicator}'")

    sql = "SELECT district, year, area_type, value FROM observations WHERE indicator = ?"
    params: list = [indicator]

    if district:
        sql += " AND district = ?"
        params.append(district)
    if area_type:
        if area_type not in ("urban", "rural"):
            conn.close()
            raise HTTPException(status_code=400, detail="area_type must be 'urban' or 'rural'")
        sql += " AND area_type = ?"
        params.append(area_type)

    sql += " ORDER BY district, year, area_type"
    rows = conn.execute(sql, params).fetchall()
    conn.close()

    return {
        "indicator": dict(meta),
        "count": len(rows),
        "data": [dict(r) for r in rows],
    }


@app.get("/api/district-latest")
def district_latest(indicator: str = Query(...)):
    """
    Return each district's most recent value for an indicator (urban+rural
    averaged), used for the district breakdown / comparison views.
    """
    conn = get_conn()
    meta = conn.execute(
        "SELECT indicator, label, unit FROM indicator_metadata WHERE indicator = ?",
        (indicator,),
    ).fetchone()
    if meta is None:
        conn.close()
        raise HTTPException(status_code=404, detail=f"Unknown indicator '{indicator}'")

    rows = conn.execute(
        """
        WITH latest_year AS (
            SELECT district, MAX(year) AS year
            FROM observations WHERE indicator = ?
            GROUP BY district
        )
        SELECT o.district, o.year, o.area_type, o.value
        FROM observations o
        JOIN latest_year ly ON o.district = ly.district AND o.year = ly.year
        WHERE o.indicator = ?
        ORDER BY o.district, o.area_type
        """,
        (indicator, indicator),
    ).fetchall()
    conn.close()

    return {"indicator": dict(meta), "data": [dict(r) for r in rows]}
